﻿using Telegram.Bot;
using Telegram;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using File = System.IO.File;

namespace PostBot
{
    class Program
    {
        static async Task Main(string[] args)
        {
            const string token = "6838046291:AAEn-wEGto5X1aOKcsv8NSZDvGpLLSYFJhM";
            string? link;

            TelegramBotHandler handler = new TelegramBotHandler(token);
            
            try
            {
                await handler.BotHandle();
            }
            catch (Exception ex)
            {
                throw new Exception("No error");
            }
        }
    }
}
