using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using System.IO;
using File = System.IO.File;

namespace PostBot
{
    public class TelegramBotHandler
    {
        public string Token { get; set; }
        public string? Link;

        public TelegramBotHandler(string token)
        {
            this.Token = token;
        }

        public async Task BotHandle()
        {
            var botClient = new TelegramBotClient(Token);

            using CancellationTokenSource cts = new CancellationTokenSource();

            ReceiverOptions receiverOptions = new ReceiverOptions
            {
                AllowedUpdates = Array.Empty<UpdateType>()
            };

            botClient.StartReceiving(
                updateHandler: HandleUpdateAsync,
                pollingErrorHandler: HandlePollingErrorAsync,
                receiverOptions: receiverOptions,
                cancellationToken: cts.Token
            );

            var me = await botClient.GetMeAsync();

            Console.WriteLine($"Start listening for @{me.Username}");
            Console.ReadLine();

            cts.Cancel();
        }

        public async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            if (update.Message?.Text is not { } messageText)
                return;

            var chatId = update.Message.Chat.Id;
            var chatBio = update.Message.Chat?.Username;

            var currentTime = DateTime.Now.ToString("HH:mm");

            string videoFilePath = "/Users/otabek_coding/Desktop/Najot Ta'lim/C# codes/Advanced/BotPractice/video-waves.mp4";

            string user_message = $"Received a '{messageText}' message in chat {chatId}.\t Bio => {chatBio}\t at {currentTime}\n";
            string filepath = $"/Users/otabek_coding/Desktop/Najot Ta'lim/C# codes/Advanced/PostBot/Output.txt";
            File.AppendAllText(filepath, user_message);

            if (messageText == "/start")
            {
                Message start = await botClient.SendTextMessageAsync(
                    chatId: chatId,
                    text: "Please enter the link of your channel\n E.X: @Otabek_Writing \n\n Make sure that you make me admin",
                    cancellationToken: cancellationToken
                    );
            }
            else if (messageText.StartsWith("@") || messageText.ToLower().StartsWith("https://t.me/"))
            {
                this.Link = messageText;
                Message linK = await botClient.SendTextMessageAsync(
                    chatId: chatId,
                    text: "Now choose a command to continue:\n/sticker\n /audio\n /video\n /minivideo\n /album\n /document\n /animation\n /contact\n /picture\n /location\n /poll",
                    cancellationToken: cancellationToken
                    );
            }
            else if (messageText == "/sticker")
            {
                // Check if Link is set
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                // Use Link for sending sticker
                Message stiker = await botClient.SendStickerAsync(
                    chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                    sticker: InputFile.FromUri("https://github.com/TelegramBots/book/raw/master/src/docs/sticker-fred.webp"),
                    cancellationToken: cancellationToken);
            }
            else if (messageText == "/audio")
            {
                // Check if Link is set
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                try
                {
                    Message audio = await botClient.SendAudioAsync(
                        chatId: Link,
                        audio: InputFile.FromUri("https://github.com/TelegramBots/book/raw/master/src/docs/audio-guitar.mp3"),
                        performer: "Joel Thomas Hunger",
                        title: "Fun Guitar and Ukulele",
                        duration: 91,
                        cancellationToken: cancellationToken);

                    Console.WriteLine($"Audio sent successfully. File ID: {audio.Audio.FileId}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error sending audio: {ex.Message}");
                }
            }
            else if (messageText == "/audio")
            {
                // Check if Link is set
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                try
                {
                    Message audio = await botClient.SendAudioAsync(
                        chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                        audio: InputFile.FromUri("https://github.com/TelegramBots/book/raw/master/src/docs/audio-guitar.mp3"),
                        performer: "Joel Thomas Hunger",
                        title: "Fun Guitar and Ukulele",
                        duration: 91,
                        cancellationToken: cancellationToken);

                    Console.WriteLine($"Audio sent successfully. File ID: {audio.Audio.FileId}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error sending audio: {ex.Message}");
                }
            }
            else if (messageText == "/video")
            {
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                try
                {
                    Message video = await botClient.SendVideoAsync(
                        chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                        video: InputFile.FromUri("https://raw.githubusercontent.com/TelegramBots/book/master/src/docs/video-countdown.mp4"),
                        thumbnail: InputFile.FromUri("https://raw.githubusercontent.com/TelegramBots/book/master/src/2/docs/thumb-clock.jpg"),
                        duration: 91,
                        supportsStreaming: true,
                        cancellationToken: cancellationToken);

                    Console.WriteLine($"Video sent successfully. File ID: {video.Video.FileId}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error sending video: {ex.Message}");
                }
            }
            else if (messageText == "/minivideo")
            {
                // Check if Link is set
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                if (File.Exists(videoFilePath))
                {
                    await using Stream stream = File.OpenRead(videoFilePath);

                    Message minivideo = await botClient.SendVideoNoteAsync(
                        chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                        videoNote: InputFile.FromStream(stream),
                        duration: 47,
                        length: 360,
                        cancellationToken: cancellationToken);
                }
                else
                {
                    Console.WriteLine($"File not found: {videoFilePath}");
                }
            }
            else if (messageText == "/album")
            {
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                Message[] album = await botClient.SendMediaGroupAsync(
                    chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                    media: new IAlbumInputMedia[]
                    {
                        new InputMediaPhoto(
                            InputFile.FromUri("https://images.app.goo.gl/mS83Wf4KGNywhQCm7")),
                        new InputMediaPhoto(
                            InputFile.FromUri("https://images.app.goo.gl/uzqVzn2m1wwrVj3d9")),
                    },
                    cancellationToken: cancellationToken);
            }
            else if (messageText == "/document")
            {
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                Message doc = await botClient.SendDocumentAsync(
                    chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                    document: InputFile.FromUri("https://github.com/TelegramBots/book/raw/master/src/docs/photo-ara.jpg"),
                    parseMode: ParseMode.Html,
                    cancellationToken: cancellationToken);
            }
            else if (messageText == "/animation")
            {
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                Message animation = await botClient.SendAnimationAsync(
                    chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                    animation: InputFile.FromUri("https://raw.githubusercontent.com/TelegramBots/book/master/src/docs/video-waves.mp4"),
                    caption: "Waves",
                    cancellationToken: cancellationToken);
            }
            else if (messageText == "/contact")
            {
                // Check if Link is set
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                Message contact_number = await botClient.SendContactAsync(
                    chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                    phoneNumber: "+998940217012",
                    firstName: "Otabek",
                    vCard: "BEGIN:VCARD\n" +
                    "VERSION:3.0\n" +
                    "N:Solo;Han\n" +
                    "ORG:Scruffy-looking nerf herder\n" +
                    "TEL;TYPE=voice,work,pref:+1234567890\n" +
                    "EMAIL:hansolo@mfalcon.com\n" +
                    "END:VCARD",
                    cancellationToken: cancellationToken);
            }
            else if (messageText == "/picture")
            {
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                Message message = await botClient.SendPhotoAsync(
                    chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                    caption: "<b>Ara bird</b>. <i>Source</i>: <a href=\"https://pixabay.com\">Pixabay</a>",
                    photo: InputFile.FromUri("https://github.com/TelegramBots/book/raw/master/src/docs/photo-ara.jpg"),
                    parseMode: ParseMode.Html,
                    cancellationToken: cancellationToken);
            }
            else if (messageText == "/location")
            {
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                Message location = await botClient.SendLocationAsync(
                    chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                    latitude: 33.747252f,
                    longitude: -112.633853f,
                    cancellationToken: cancellationToken);
            }
            else if (messageText == "/poll")
            {
                if (string.IsNullOrEmpty(Link))
                {
                    await botClient.SendTextMessageAsync(chatId, "Please provide the channel link or username first.");
                    return;
                }

                Message pollMessage = await botClient.SendPollAsync(
                    chatId: Link.StartsWith("@") ? Link : long.Parse(Link),
                    question: "Did you ever hear the tragedy of Darth Plagueis The Wise?",
                    options: new[]
                    {
                        "Yes for the hundredth time!",
                        "No, who`s that?"
                    },
                    cancellationToken: cancellationToken);
            }
            else
            {
                await botClient.SendTextMessageAsync(
                    chatId: chatId,
                    text: "You said:\n" + messageText + $" at {currentTime}\n",
                    cancellationToken: cancellationToken);
            }
        }
        

        public Task HandlePollingErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
        {
            var errorMessage = exception switch
            {
                ApiRequestException apiRequestException
                    => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
                _ => exception.ToString()
            };

            Console.WriteLine(errorMessage);
            return Task.CompletedTask;
        }
    }
}